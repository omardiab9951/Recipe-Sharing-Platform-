<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? $page_title : 'Recipe Sharing Platform'; ?></title>

  <!-- CSS Files -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/forms.css">
  <link rel="stylesheet" href="assets/css/cards.css">
  <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body>
  <header class="site-header">
    <div class="container">
      <div class="header-content">
        <a href="index.php" class="logo">
          🍳 Culinary Compass
        </a>

        <nav class="main-nav">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="browse.php">Browse Recipes</a></li>

            <?php if (isset($_SESSION['user_id'])): ?>
              <li><a href="add-recipe.php" class="btn btn-primary">Add Recipe</a></li>
              <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                <li><a href="admin-panel.php" class="btn btn-admin">👑 Admin Panel</a></li>
              <?php endif; ?>
              <li>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                  <span style="background: #ef4444; color: white; padding: 2px 8px; border-radius: 12px; font-size: 11px; margin-left: 5px;">ADMIN</span>
                <?php endif; ?>
              </li>
              <li><a href="logout.php" class="btn btn-logout">Logout</a></li>
            <?php else: ?>

              <li><a href="login.php" class="btn btn-login">Login</a></li>
              <li><a href="register.php" class="btn btn-register">Register</a></li>
            <?php endif; ?>
          </ul>
        </nav>
      </div>
    </div>
  </header>