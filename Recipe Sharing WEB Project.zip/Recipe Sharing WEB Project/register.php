<?php
session_start();
require_once 'config/database.php';

$page_title = 'Register - Recipe Sharing Platform';
$error = '';
$success = '';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
  header('Location: index.php');
  exit;
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']);
  $email = trim($_POST['email']);
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];

  // Validation
  if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
    $error = 'Please fill in all fields';
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Invalid email format';
  } elseif (strlen($password) < 6) {
    $error = 'Password must be at least 6 characters';
  } elseif ($password !== $confirm_password) {
    $error = 'Passwords do not match';
  } else {
    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->fetch()) {
      $error = 'Email already registered';
    } else {
      // Insert new user - FIXED: using password_hash instead of password
      $hashed_password = password_hash($password, PASSWORD_DEFAULT);
      $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");

      if ($stmt->execute([$name, $email, $hashed_password])) {
        $success = 'Registration successful! You can now login.';
      } else {
        $error = 'Registration failed. Please try again.';
      }
    }
  }
}

include 'includes/header.php';
?>

<section class="auth-section">
  <div class="container">
    <div class="auth-container">
      <h2>Create Your Account</h2>

      <?php if ($error): ?>
        <div class="alert alert-error" style="background: #fee2e2; border: 1px solid #fca5a5; padding: 15px; margin: 15px 0; border-radius: 8px; color: #991b1b;">
          ⚠️ <?php echo htmlspecialchars($error); ?>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert alert-success" style="background: #d1fae5; border: 1px solid #6ee7b7; padding: 15px; margin: 15px 0; border-radius: 8px; color: #065f46;">
          ✅ <?php echo htmlspecialchars($success); ?>
          <br><a href="login.php" style="color: #059669; font-weight: bold;">Click here to login →</a>
        </div>
      <?php endif; ?>

      <form method="POST" action="register.php" class="auth-form">
        <div class="form-group">
          <label for="name">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            required
            value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin-top: 5px;">
        </div>

        <div class="form-group">
          <label for="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            required
            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin-top: 5px;">
        </div>

        <div class="form-group">
          <label for="password">Password (min. 6 characters)</label>
          <input
            type="password"
            id="password"
            name="password"
            required
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin-top: 5px;">
        </div>

        <div class="form-group">
          <label for="confirm_password">Confirm Password</label>
          <input
            type="password"
            id="confirm_password"
            name="confirm_password"
            required
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin-top: 5px;">
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="width: 100%; padding: 12px; background: #d97706; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 10px;">Register</button>
      </form>

      <p class="auth-switch" style="text-align: center; margin-top: 20px;">
        Already have an account? <a href="login.php" style="color: #d97706;">Login here</a>
      </p>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>