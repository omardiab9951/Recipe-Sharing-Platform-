<?php
session_start();
require_once 'config/database.php';

$page_title = 'Login - Recipe Sharing Platform';
$error = '';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
  header('Location: index.php');
  exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email']);
  $password = $_POST['password'];

  if (empty($email) || empty($password)) {
    $error = 'Please fill in all fields';
  } else {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
      // Check both 'password' and 'password_hash' columns
      $db_password = isset($user['password_hash']) ? $user['password_hash'] : $user['password'];

      // Verify password (works with both hashed and plain text)
      if (password_verify($password, $db_password) || $password === $db_password) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = isset($user['role']) ? $user['role'] : 'user';

        header('Location: index.php');
        exit;
      } else {
        $error = 'Invalid password';
      }
    } else {
      $error = 'No user found with email: ' . htmlspecialchars($email);
    }
  }
}

include 'includes/header.php';
?>

<section class="auth-section">
  <div class="container">
    <div class="auth-container">
      <h2>Login to Your Account</h2>

      <?php if ($error): ?>
        <div class="alert alert-error" style="background: #fee2e2; border: 1px solid #fca5a5; padding: 15px; margin: 15px 0; border-radius: 8px; color: #991b1b;">
          ⚠️ <?php echo $error; ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="login.php" class="auth-form">
        <div class="form-group">
          <label for="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            required
            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            required
            style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="width: 100%; padding: 12px; background: #3b82f6; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">Login</button>
      </form>

      <p class="auth-switch" style="text-align: center; margin-top: 20px;">
        Don't have an account? <a href="register.php" style="color: #3b82f6;">Register here</a>
      </p>

      <div style="background: #eff6ff; border: 1px solid #bfdbfe; padding: 15px; margin-top: 20px; border-radius: 8px;">
        <strong>💡 Test Credentials:</strong><br>
        Email: <code>sut.edu.eg@gmail.com</code><br>
        Password: Try <code>admin123</code> or <code>admin</code> or <code>123456</code>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>