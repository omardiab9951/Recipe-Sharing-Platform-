<?php
session_start();
require_once 'config/database.php';

$page_title = 'Browse Recipes - Recipe Sharing Platform';

// Get category filter if exists
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

// Get search query if exists
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query based on filters
if ($category && $search) {
  $stmt = $pdo->prepare("
        SELECT r.*, u.name as author_name 
        FROM recipes r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.category = ? AND (r.title LIKE ? OR r.ingredients LIKE ?)
        ORDER BY r.created_at DESC
    ");
  $searchTerm = "%{$search}%";
  $stmt->execute([$category, $searchTerm, $searchTerm]);
} elseif ($category) {
  $stmt = $pdo->prepare("
        SELECT r.*, u.name as author_name 
        FROM recipes r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.category = ?
        ORDER BY r.created_at DESC
    ");
  $stmt->execute([$category]);
} elseif ($search) {
  $stmt = $pdo->prepare("
        SELECT r.*, u.name as author_name 
        FROM recipes r 
        JOIN users u ON r.user_id = u.id 
        WHERE r.title LIKE ? OR r.ingredients LIKE ? OR r.category LIKE ?
        ORDER BY r.created_at DESC
    ");
  $searchTerm = "%{$search}%";
  $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
} else {
  $stmt = $pdo->query("
        SELECT r.*, u.name as author_name 
        FROM recipes r 
        JOIN users u ON r.user_id = u.id 
        ORDER BY r.created_at DESC
    ");
}

$recipes = $stmt->fetchAll();

include 'includes/header.php';
?>

<section class="page-header">
  <div class="container">
    <h1>Browse All Recipes</h1>
    <p>Discover amazing recipes from our community</p>
  </div>
</section>

<!-- Filter Section -->
<section class="filter-section">
  <div class="container">
    <div class="filter-bar">
      <div class="category-filters">
        <a href="browse.php" class="filter-btn <?php echo !$category ? 'active' : ''; ?>">All</a>
        <a href="browse.php?category=Breakfast" class="filter-btn <?php echo $category === 'Breakfast' ? 'active' : ''; ?>">🥞 Breakfast</a>
        <a href="browse.php?category=Lunch" class="filter-btn <?php echo $category === 'Lunch' ? 'active' : ''; ?>">🥗 Lunch</a>
        <a href="browse.php?category=Dinner" class="filter-btn <?php echo $category === 'Dinner' ? 'active' : ''; ?>">🍝 Dinner</a>
        <a href="browse.php?category=Dessert" class="filter-btn <?php echo $category === 'Dessert' ? 'active' : ''; ?>">🍰 Dessert</a>
      </div>

      <form method="GET" action="browse.php" class="search-form-inline">
        <?php if ($category): ?>
          <input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">
        <?php endif; ?>
        <input
          type="text"
          name="search"
          placeholder="Search recipes..."
          value="<?php echo htmlspecialchars($search); ?>"
          class="search-input-small">
        <button type="submit" class="btn btn-primary">Search</button>
      </form>
    </div>
  </div>
</section>

<!-- Recipes Grid -->
<section class="recipes-section">
  <div class="container">
    <?php if ($category): ?>
      <h2><?php echo htmlspecialchars($category); ?> Recipes (<?php echo count($recipes); ?>)</h2>
    <?php elseif ($search): ?>
      <h2>Search Results for "<?php echo htmlspecialchars($search); ?>" (<?php echo count($recipes); ?>)</h2>
    <?php else: ?>
      <h2>All Recipes (<?php echo count($recipes); ?>)</h2>
    <?php endif; ?>

    <?php if (count($recipes) > 0): ?>
      <div class="recipe-grid">
        <?php foreach ($recipes as $recipe): ?>
          <article class="recipe-card">
            <a href="recipe-detail.php?id=<?php echo $recipe['id']; ?>" class="recipe-card-link">
              <div class="recipe-card-image">
                <?php if (!empty($recipe['image']) && file_exists('assets/uploads/' . $recipe['image'])): ?>
                  <img src="assets/uploads/<?php echo htmlspecialchars($recipe['image']); ?>"
                    alt="<?php echo htmlspecialchars($recipe['title']); ?>">
                <?php else: ?>
                  <div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #fef3c7, #fde68a); color: #d97706; font-size: 18px; font-weight: 600;">
                    🍽️ <?php echo htmlspecialchars($recipe['title']); ?>
                  </div>
                <?php endif; ?>

                <span class="recipe-category-badge">
                  <?php echo htmlspecialchars($recipe['category']); ?>
                </span>
              </div>

              <div class="recipe-card-content">
                <h3 class="recipe-card-title">
                  <?php echo htmlspecialchars($recipe['title']); ?>
                </h3>

                <p class="recipe-card-description">
                  <?php
                  $ingredients = htmlspecialchars($recipe['ingredients']);
                  echo substr($ingredients, 0, 100) . (strlen($ingredients) > 100 ? '...' : '');
                  ?>
                </p>

                <div class="recipe-card-meta">
                  <span class="recipe-author">
                    By <?php echo htmlspecialchars($recipe['author_name']); ?>
                  </span>
                  <span class="recipe-date">
                    <?php echo date('M d, Y', strtotime($recipe['created_at'])); ?>
                  </span>
                </div>
              </div>
            </a>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="no-recipes">
        <p>No recipes found. <?php echo isset($_SESSION['user_id']) ? 'Be the first to add one!' : 'Register to add recipes!'; ?></p>
        <?php if (isset($_SESSION['user_id'])): ?>
          <a href="add-recipe.php" class="btn btn-primary">Add Recipe</a>
        <?php else: ?>
          <a href="register.php" class="btn btn-primary">Register Now</a>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php include 'includes/footer.php'; ?>