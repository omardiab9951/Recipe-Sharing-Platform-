<?php
session_start();
require_once 'config/database.php';

// Get recipe ID
$recipe_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$recipe_id) {
    header('Location: index.php');
    exit;
}

// Fetch recipe details
$stmt = $pdo->prepare("
    SELECT r.*, u.name as author_name, u.email as author_email
    FROM recipes r
    JOIN users u ON r.user_id = u.id
    WHERE r.id = ?
");
$stmt->execute([$recipe_id]);
$recipe = $stmt->fetch();

if (!$recipe) {
    header('Location: index.php');
    exit;
}

$page_title = htmlspecialchars($recipe['title']) . ' - Recipe Sharing Platform';

include 'includes/header.php';
?>

<section class="recipe-detail-section">
    <div class="container">
        <div class="recipe-detail-header">
            <h1><?php echo htmlspecialchars($recipe['title']); ?></h1>
            <div class="recipe-meta">
                <span class="recipe-category-badge"><?php echo htmlspecialchars($recipe['category']); ?></span>
                <span>By <?php echo htmlspecialchars($recipe['author_name']); ?></span>
                <span><?php echo date('M d, Y', strtotime($recipe['created_at'])); ?></span>
            </div>
        </div>

        <div class="recipe-detail-content">
            <div class="recipe-detail-image">
                <?php if (!empty($recipe['image']) && file_exists('assets/uploads/' . $recipe['image'])): ?>
                    <img src="assets/uploads/<?php echo htmlspecialchars($recipe['image']); ?>"
                        alt="<?php echo htmlspecialchars($recipe['title']); ?>">
                <?php else: ?>
                    <div style="width: 100%; height: 400px; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #fef3c7, #fde68a); color: #d97706; font-size: 24px; font-weight: 600; border-radius: 12px;">
                        🍽️ <?php echo htmlspecialchars($recipe['title']); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="recipe-detail-info">
                <section class="recipe-section">
                    <h2>Ingredients</h2>
                    <div class="recipe-text">
                        <?php echo nl2br(htmlspecialchars($recipe['ingredients'])); ?>
                    </div>
                </section>

                <section class="recipe-section">
                    <h2>Instructions</h2>
                    <div class="recipe-text">
                        <?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?>
                    </div>
                </section>

                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $recipe['user_id']): ?>
                    <div class="recipe-actions">
                        <a href="edit-recipe.php?id=<?php echo $recipe['id']; ?>" class="btn btn-primary">Edit Recipe</a>
                        <a href="delete-recipe.php?id=<?php echo $recipe['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this recipe?')">Delete Recipe</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="back-link">
            <a href="index.php" class="btn btn-secondary">← Back to Recipes</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>