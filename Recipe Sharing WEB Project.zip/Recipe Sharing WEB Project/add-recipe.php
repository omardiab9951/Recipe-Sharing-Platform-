<?php

/**
 * File: add-recipe.php
 * Purpose: Recipe submission form page
 * Author: B2 Team Member
 * Date: December 2025
 */

require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/controllers/RecipeController.php';
require_once __DIR__ . '/controllers/AuthController.php';

// Require login
requireLogin();

$recipeController = new RecipeController();
$authController = new AuthController();
$errors = [];
$success_message = '';

// Form values
$title = '';
$category = '';
$ingredients = '';
$instructions = '';

// Generate CSRF token
$csrf_token = $authController->generateCSRFToken();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !$authController->verifyCSRFToken($_POST['csrf_token'])) {
        $errors['general'] = 'Invalid request. Please try again.';
    } else {
        $title = $_POST['title'] ?? '';
        $category = $_POST['category'] ?? '';
        $ingredients = $_POST['ingredients'] ?? '';
        $instructions = $_POST['instructions'] ?? '';
        $image = $_FILES['image'] ?? null;

        $result = $recipeController->createRecipe(
            $_SESSION['user_id'],
            $title,
            $category,
            $ingredients,
            $instructions,
            $image
        );

        if ($result['success']) {
            $success_message = $result['message'];
            // Clear form
            $title = '';
            $category = '';
            $ingredients = '';
            $instructions = '';

            // Redirect to recipe detail page
            header("Location: recipe-detail.php?id=" . $result['recipe_id']);
            exit();
        } else {
            $errors = $result['errors'];
        }
    }
}

// Categories list
$categories = ['Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snacks', 'Beverages'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Recipe - Recipe Sharing Platform</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/forms.css">
</head>

<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <main class="add-recipe-container">
        <div class="container">
            <h1>Share Your Recipe</h1>

            <?php if ($success_message): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($errors['general']); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="add-recipe.php" enctype="multipart/form-data" class="recipe-form">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

                <div class="form-group">
                    <label for="title">Recipe Title *</label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        value="<?php echo htmlspecialchars($title); ?>"
                        placeholder="Enter recipe title"
                        required>
                    <?php if (isset($errors['title'])): ?>
                        <span class="error-message"><?php echo htmlspecialchars($errors['title']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="category">Category *</label>
                    <select id="category" name="category" required>
                        <option value="">Select a category</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat; ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                                <?php echo $cat; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (isset($errors['category'])): ?>
                        <span class="error-message"><?php echo htmlspecialchars($errors['category']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="ingredients">Ingredients *</label>
                    <textarea
                        id="ingredients"
                        name="ingredients"
                        rows="6"
                        placeholder="List all ingredients (one per line)"
                        required><?php echo htmlspecialchars($ingredients); ?></textarea>
                    <?php if (isset($errors['ingredients'])): ?>
                        <span class="error-message"><?php echo htmlspecialchars($errors['ingredients']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="instructions">Instructions *</label>
                    <textarea
                        id="instructions"
                        name="instructions"
                        rows="8"
                        placeholder="Describe the cooking steps"
                        required><?php echo htmlspecialchars($instructions); ?></textarea>
                    <?php if (isset($errors['instructions'])): ?>
                        <span class="error-message"><?php echo htmlspecialchars($errors['instructions']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="image">Recipe Image (Optional)</label>
                    <input
                        type="file"
                        id="image"
                        name="image"
                        accept="image/jpeg,image/jpg,image/png,image/gif">
                    <small>Max size: 5MB. Formats: JPG, PNG, GIF</small>
                    <?php if (isset($errors['image'])): ?>
                        <span class="error-message"><?php echo htmlspecialchars($errors['image']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Submit Recipe</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </main>

    <?php include __DIR__ . '/includes/footer.php'; ?>
</body>

</html>